import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class Entry {
	public static void main(String[] args) {
		
		Set<Integer> setOfValues = new HashSet<>();
		
		
		setOfValues.add(12);
		setOfValues.add(2);
		setOfValues.add(21);
		setOfValues.add(new Integer(1));
		
		for(int v : setOfValues){
			System.out.print(v+ "\t");
		}
		
		System.out.println();
		System.out.println( setOfValues.contains(new Integer(1)));;
		
		Set<Person> persons = new HashSet<Person>();
		
		persons.add(new Person("Mark", 23));
		persons.add(new Person("Lisa", 21));
		
		Person p = new Person("John", 25);
		
		persons.add(p);
		
		
		System.out.println( persons.contains(new Person("John", 28)));;
		
		
		
	}
}
