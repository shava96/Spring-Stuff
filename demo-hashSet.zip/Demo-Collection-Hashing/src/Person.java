
public class Person {

	private String name;
	private int age;

	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	@Override
	public String toString() {
		return name + "/"+ age;
	}
	
	@Override
	public boolean equals(Object obj) {
		
		if(this.age != ((Person)obj).age  )
			return false;
		
		return this.name.equals(((Person)obj).name);
		
	}
	
	
	@Override
	public int hashCode() {
		System.out.println(this + " has "+ age);
		return (age % 3);
		
/*		System.out.println(this + " has "+ super.hashCode());
		return super.hashCode();
*/	}
	
	
	
	public int getAge() {
		return age;
	}
	
	public String getName() {
		return name;
	}
}
